package wsclient;

public interface Hello {

	String sayHello(String string);

}
