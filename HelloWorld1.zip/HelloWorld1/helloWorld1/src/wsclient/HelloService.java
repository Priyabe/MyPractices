package wsclient;

public class HelloService {

	public Hello getHelloPort() {
	
		return null;
	}

}
