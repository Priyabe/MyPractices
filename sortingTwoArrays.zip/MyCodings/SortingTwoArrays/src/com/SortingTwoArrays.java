package com;
import java.util.Arrays;
public class SortingTwoArrays {

	public static void main(String[] args) {
		String names[]= {"devi","anbu","sathya","priya"};
		int ids[]= {1,2,3,4};
		for(int i=0;i<names.length;i++)
		{
			for(int j=i+1;j<names.length;j++) {
				if(names[i].compareTo(names[j])>0) {
					String temp=names[i];
				names[i]=names[j];
				names[j]=temp;
				int tempInt=ids[i];
				ids[i]=ids[j];
				ids[j]=tempInt;
				}
			}
		}
		System.out.println(Arrays.toString(names));
		System.out.println(Arrays.toString(ids));

	}

}
