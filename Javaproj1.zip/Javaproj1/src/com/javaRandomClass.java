package com;
import java.util.Random;
public class javaRandomClass {
	
	    public static void main(String[] args) {
	        for (int i = 1; i < 3; i++) {
	            System.out.println("Random Number:- " + randomNumberInRange(10, 20));
	        }
	    }
	 
	    public static int randomNumberInRange(int min, int max) {
	        Random random = new Random();
	        return random.nextInt((max - min) + 1) + min;
	    }
	}
