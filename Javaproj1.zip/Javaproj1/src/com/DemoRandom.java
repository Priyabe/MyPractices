package com;
		public class DemoRandom{
			  public static void main(String[] args) {
			    for(int xCount = 0; xCount< 10; xCount++){
			      System.out.println(Math.random());
			    }
			  }
			}

	
