		package com;

		import java.util.Arrays;

		public class sortingArrays {
			public static void main(String[] args) {
			String names[]= {"devi","anbu","sathya","priya"};
			int ids[]= {1,2,3,4};
			for(int i=0;i<names.length;i++)
			{
				for(int j=i+1;j<names.length;j++) {
					if(names[i].compareTo(names[j])>0) {
						String temp=names[i];
					names[i]=names[j];
					names[j]=temp;
					int tempInt=ids[i];
					ids[i]=ids[j];
					ids[j]=tempInt;
					}
				}
			}
			System.out.println(Arrays.toString(names));
			System.out.println(Arrays.toString(ids));
			}
		
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
//			for(int i=0,n=a.length;i<n;i++)
//			{
//				for(int j = i+1;j<n;j++)
//				{
//					if(a[i] > a[j] )
//					{
//						String temp=a[i];
//						int tempInt=in[i];
//						a[i]=a[j];
//						in[i]=in[j];
//						in[j]=tempInt;
//					
//					}
//				}
		//
//			}
		//System.out.println(a);
		//for(int i=0,n=a.length;i<n;i++) {
//			System.out.println(in[i]);	
		//}
		//
//			}
		//}


	}

