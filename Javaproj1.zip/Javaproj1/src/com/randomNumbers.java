package com;
		import java.util.Random;
		public class randomNumbers {

			public static void main(String[] args) {
				Random rand1=new Random();
				Random rand2=new Random();
				{
					int num1=rand1.nextInt(10)+10;	
					int num2=rand2.nextInt(10)+10;
					System.out.println(num1);
					System.out.println(num2);
				}
	}

}
