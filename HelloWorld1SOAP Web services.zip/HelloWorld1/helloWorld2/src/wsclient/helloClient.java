package wsclient;

import wsserver.hello;

public class helloClient {
	public static void main(String[] args) {
		helloService service = new helloService();
		hello hello = service.getHelloPort();
		String text = hello.sayHello("Hello");
		System.out.println(text);
	}
}
