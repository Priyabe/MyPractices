package wsclient;

import wsserver.hello;

public class helloService {

	public hello getHelloPort() {
		// TODO Auto-generated method stub
		return null;
	}

}
