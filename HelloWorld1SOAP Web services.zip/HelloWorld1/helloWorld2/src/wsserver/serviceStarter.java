package wsserver;
import javax.xml.ws.Endpoint;
public class serviceStarter {
	public static void main(String[] args) {
		String url = "http://localhost:1212/hello";
		Endpoint.publish(url, new hello());
		System.out.println("Service started @ " + url);

	}

}

